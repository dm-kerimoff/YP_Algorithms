"""
id посылки - 86305374

Этапы решения задачи:
 а) Построение бора - префиксного дерева, в терминальных узлах которого расположена длина слова
 б) Построение булевого динамического массива dp[i] - возможность создания строки с индексом i

 Ответ на вопрос задачи - это dp[-1]

Временная сложность:
    Построение бора: O(L), где L — суммарная длина слов во множестве
    Проход по дереву - O(n^2), где n - длина текста

Пространственная сложность:
    Бор: O(L), где L — суммарная длина слов во множестве
    Текст: O(n), где n - длина текста
"""


class Node:
    def __init__(self, value, next=None):
        self.value = value
        self.next = {} if next is None else next
        self.terminal = False


def bor_create(words):  # Функция построения префиксного дерева с возвращением корня бора
    root = Node('')
    for word in words:
        node = root

        for char in word:
            node.next[char] = node.next.get(char, Node(char))
            node = node.next[char]
        node.terminal = len(word)       # Длина слова записана в терминальном узле

    return root


def is_split_text(text, words):
    root = bor_create(words)        # Бор с корнем root создан
    dp = [True] + [False] * len(text)   # Булевый динамический массив
    for i in range(len(text)):
        node = root
        if dp[i]:
            for j in range(i, len(text) + 1):
                if node.terminal:
                    dp[j] = True
                if j == len(text) or not node.next.get(text[j], False):
                    break
                node = node.next[text[j]]
    return dp[-1]


def main():
    text = input()  # Данный текст
    words = [input() for _ in range(int(input()))]  # список допустимых к использованию слов
    print('YES' if is_split_text(text, words) else 'NO')


if __name__ == "__main__":
    main()
