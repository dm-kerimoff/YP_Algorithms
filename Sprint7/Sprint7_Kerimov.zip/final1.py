"""
id посылки - 84703487
Идея для решения задачи и дополнительная теория взяты с https://habr.com/ru/post/676858/

Временная сложность - O(m*n), где m,n - длины строк

Пространственная сложность: O(m*n)

"""

import itertools


def levenshtein_distance(s, t):
    m, n = len(s) + 1, len(t) + 1
    d = [[0] * n for _ in range(m)]

    for i in range(1, m):
        d[i][0] = i

    for j in range(1, n):
        d[0][j] = j

    for j, i in itertools.product(range(1, n), range(1, m)):
        substitution_cost = 0 if s[i - 1] == t[j - 1] else 1
        d[i][j] = min(d[i - 1][j] + 1,
                      d[i][j - 1] + 1,
                      d[i - 1][j - 1] + substitution_cost)

    return d[m - 1][n - 1]


def main():
    str_1, str_2 = input(), input()
    print(levenshtein_distance(str_1, str_2))


if __name__ == '__main__':
    main()
